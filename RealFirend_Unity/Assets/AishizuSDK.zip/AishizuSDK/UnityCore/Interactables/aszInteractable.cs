using UnityEngine;

public abstract class aszInteractable : MonoBehaviour
{
    [SerializeField] private Transform InteractTransform;
}
