namespace Aishizu.UnityCore
{
    public enum Result
    {
        Unkown = -1,
        Success = 1,
        Failed = 2,
    }
}
